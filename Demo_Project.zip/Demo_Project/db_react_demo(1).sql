-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 12, 2022 at 07:27 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_react_demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company_name`
--

CREATE TABLE `tbl_company_name` (
  `id` bigint(20) NOT NULL,
  `name` varchar(32) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_company_name`
--

INSERT INTO `tbl_company_name` (`id`, `name`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Asus', 1, '2022-10-06 11:11:17', '2022-10-11 04:10:21'),
(2, 'Dell', 1, '2022-10-06 11:11:17', '2022-10-11 04:11:07'),
(3, 'Acer', 1, '2022-10-06 11:11:36', '2022-10-11 04:11:22'),
(4, 'HP', 1, '2022-10-06 11:11:36', '2022-10-11 04:11:43');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `product_qty` int(3) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `user_id`, `product_id`, `product_qty`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 8, 1, 1, '2022-10-12 04:03:12', '2022-10-12 04:03:12'),
(2, 1, 5, 1, 1, '2022-10-12 04:11:09', '2022-10-12 04:11:09'),
(3, 1, 6, 1, 1, '2022-10-12 05:22:38', '2022-10-12 05:22:38');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` bigint(20) NOT NULL,
  `company_id` bigint(20) NOT NULL,
  `image` varchar(256) NOT NULL,
  `product_name` varchar(32) NOT NULL,
  `product_specification` text NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `os_version` varchar(32) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `company_id`, `image`, `product_name`, `product_specification`, `price`, `os_version`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 'https://www.91-cdn.com/hub/wp-content/uploads/2022/01/Acer-Aspire-7-2021.jpg?tr=q-100', 'Asus', 'Memory. 8GB / 16GB 3200 MHz DDR4.\r\n', '25000.00', 'Windows11', 1, '2022-10-06 11:26:27', '2022-10-11 04:22:05'),
(2, 2, 'https://i.ytimg.com/vi/tIof7h6Pzjs/maxresdefault.jpg', 'Dell', 'Up to 8GB RAM with RAM Plus,\r\nMonster 7000mAh battery,\r\nAuto Data Switching.', '20000.00', 'Windows11', 1, '2022-10-06 11:26:27', '2022-10-11 04:50:29'),
(3, 2, 'https://i.ytimg.com/vi/tIof7h6Pzjs/maxresdefault.jpg', 'Dell', 'Up to 8GB RAM with RAM Plus,\r\nMonster 5000mAh battery,\r\nAuto Data Switching.', '21000.00', 'Windows11', 1, '2022-10-06 11:26:27', '2022-10-11 04:50:25'),
(4, 1, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQavfSCqNHqpWPq-599ufp5s1tHnwgQnbnFbQ&usqp=CAU', 'Asus', 'Memory. 8GB / 16GB 3200 MHz DDR4.\r\n', '51000.00', 'Windows11', 1, '2022-10-06 11:26:27', '2022-10-11 04:22:14'),
(5, 4, 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTh8fGludGVybmV0JTIwdGVjaG5vbG9neXxlbnwwfHwwfHw%3D&w=1000&q=80', 'HP', 'Memory. 8GB / 16GB 3200 MHz DDR4.\r\n', '25000.00', 'Windows11', 1, '2022-10-06 11:26:27', '2022-10-11 05:05:57'),
(6, 3, 'https://os-wordpress-media.s3.ap-south-1.amazonaws.com/blog/wp-content/uploads/2022/05/20040901/Acer-Spin-5.png', 'Acer', 'Memory. 8GB / 16GB 3200 MHz DDR4.', '27000.00', 'Windows11', 1, '2022-10-06 11:26:27', '2022-10-11 04:58:03'),
(7, 4, 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTh8fGludGVybmV0JTIwdGVjaG5vbG9neXxlbnwwfHwwfHw%3D&w=1000&q=80', 'HP', 'Memory. 8GB / 16GB 3200 MHz DDR4.\r\n', '22000.00', 'Windows11', 1, '2022-10-06 11:26:27', '2022-10-11 05:01:30'),
(8, 3, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGTfYetNfPGzbD49JnbRPe5vLsnVm8we54aJiW9FPJc0DXkGl7Hk51gg4DOMqNpbXPHO4&usqp=CAU', 'Acer', 'Memory. 8GB / 16GB 3200 MHz DDR4.', '18000.00', 'Windows11', 1, '2022-10-06 11:26:27', '2022-10-11 04:54:54');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` bigint(20) NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `email` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `language` enum('en') DEFAULT NULL,
  `is_online` tinyint(1) DEFAULT 0,
  `last_login` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `password`, `language`, `is_online`, `last_login`, `is_deleted`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Rahul', 'Rahulmeenaglc847@gmail.com', '12345', 'en', 1, '2022-10-12 10:50:35', 0, 1, '2022-10-11 05:45:53', '2022-10-12 05:20:35'),
(2, 'Vikash', 'Vikash@gmail.com', '1234', 'en', 0, '2022-10-11 16:24:30', 0, 1, '2022-10-11 10:54:30', '2022-10-11 10:54:30'),
(3, 'Suryakumar', 'Suryakumar@gmail.com', 'virat@123', 'en', 1, '2022-10-12 10:38:43', 0, 1, '2022-10-12 04:52:26', '2022-10-12 05:08:43');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_device`
--

CREATE TABLE `tbl_user_device` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `token` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user_device`
--

INSERT INTO `tbl_user_device` (`id`, `user_id`, `token`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 'zyenkj9goq2p8tpu301ognz2a15qtdjnkmyo6ek9ni69ycivyxczyc2tjnuhcfmf', 1, '2022-10-11 05:45:53', '2022-10-12 05:20:35'),
(2, 2, '', 1, '2022-10-11 10:54:30', '2022-10-11 12:46:58'),
(3, 3, 'yy7lfal8e16jb4h3yist06rbz4mf1yutr8qj1aq7axp0ftoq693oe6u0wlhjbnhz', 1, '2022-10-12 04:52:26', '2022-10-12 05:08:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_company_name`
--
ALTER TABLE `tbl_company_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_user_device`
--
ALTER TABLE `tbl_user_device`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_company_name`
--
ALTER TABLE `tbl_company_name`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_user_device`
--
ALTER TABLE `tbl_user_device`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
