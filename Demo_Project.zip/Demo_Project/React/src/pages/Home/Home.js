import React, { useEffect, useState } from 'react'
import { Helmet } from 'react-helmet'
import { Homepage, AddtoCart } from '../../api/apiHandler'

export default function Home() {
  var [data, setData] = useState([]);
  function addDatatoCart(id) {
    console.log("hello", id)


    const cart = {
      product_id: id,
      product_qty: '1',

    }

    AddtoCart(cart).then((res) => {
      console.log("Profile Data", res.data)
      if (res.data.code == 1) {
        console.log("Success")
        alert("Add in cart successfully");
      }
      else {
        console.log("Success")
        alert("Add in cart successfully");
      }
    });
  }

  useEffect(() => {
    Homepage().then((resposnse) => {
      if (resposnse.data.code == 1) {
        setData(resposnse.data)
      } else {
        console.log('data not found')
      }
    });
  }, []);
  return (

    <>
      <Helmet>
        <style>{`
         .card-title{
          color: black;       }
       .namee{
      
        color: white !important;
       }
         `}   
        </style>
      </Helmet>
      <div className="form-row-last">

      </div>
      <div className="container-fluid mt-5 mb-4">
        <div className="card">

          <div className="card-body bg-dark">
            <h2 className="namee text-center ">Laptops</h2>

          </div>
        </div>
        <div className="row pt-3 pb-5">

          {data.data?.map((laptopdata, index) => {
            return (
              <div key={index} className="col-lg-3 col-md-6 mt-sm-20" >
                <div className="card my-3" >
                  <img src={laptopdata.image} className="card-img-top" alt="..." />
                  <div className="card-body">
                    <h5 className="card-title text-center" > {laptopdata.product_name}</h5>
                    <div className="col text-left my-3">
                      <p><b>Detail :</b> {laptopdata.product_specification}</p>

                    </div>
                    <div className="row pb-4 pt-2">
                      <div className="col">
                        <h5>Price :{laptopdata.price}</h5>
                      </div>
                      <div className="col text-right">
                        <h5>Version :{laptopdata.os_version}</h5>
                      </div>
                    </div>
                    <button type="button" class="btn btn-primary"><a onClick={() => addDatatoCart(laptopdata.id)}> Add to cart</a></button>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>

    </>
  )
}
